﻿
//Q6
using System;

class Program
{
    static void Main()
    {
        Console.Write("Enter student's name: ");
        string name = Console.ReadLine();

        Console.Write("Enter exam marks: ");
        int marks;
        if (!int.TryParse(Console.ReadLine(), out marks) || marks < 0 || marks > 100)
        {
            Console.WriteLine("Error: Marks should be between 0 and 100.");
            return;
        }

        string grade = "";
        if (marks >= 75)
        {
            grade = "A";
        }
        else if (marks >= 60)
        {
            grade = "B";
        }
        else if (marks >= 50)
        {
            grade = "C";
        }
        else if (marks >= 40)
        {
            grade = "D";
        }
        else
        {
            grade = "Fail";
        }

        Console.WriteLine($"Student Name: {name}");
        Console.WriteLine($"Grade: {grade}");
    }
}
