﻿//Q7

using System;

class Program
{
    static decimal balance = 0;

    static void Main()
    {
        while (true)
        {
            Console.WriteLine("ATM Menu:");
            Console.WriteLine("1. Check Balance");
            Console.WriteLine("2. Deposit Money");
            Console.WriteLine("3. Withdraw Money");
            Console.WriteLine("4. Exit");

            Console.Write("Enter your choice: ");
            int choice = int.Parse(Console.ReadLine());

            switch (choice)
            {
                case 1:
                    Console.WriteLine($"Your balance: {balance}");
                    break;
                case 2:
                    Console.Write("Enter amount to deposit: ");
                    decimal depositAmount = decimal.Parse(Console.ReadLine());
                    Deposit(depositAmount);
                    break;
                case 3:
                    Console.Write("Enter amount to withdraw: ");
                    decimal withdrawAmount = decimal.Parse(Console.ReadLine());
                    Withdraw(withdrawAmount);
                    break;
                case 4:
                    Console.WriteLine("Thank you for using the ATM. Goodbye!");
                    return;
                default:
                    Console.WriteLine("Invalid choice. Please try again.");
                    break;
            }
        }
    }

    static void Deposit(decimal amount)
    {
        balance += amount;
        Console.WriteLine($"Deposit of {amount} successful. New balance: {balance}");
    }

    static void Withdraw(decimal amount)
    {
        if (amount > balance)
        {
            Console.WriteLine("Insufficient funds. Withdrawal failed.");
        }
        else
        {
            balance -= amount;
            Console.WriteLine($"Withdrawal of {amount} successful. New balance: {balance}");
        }
    }
}

