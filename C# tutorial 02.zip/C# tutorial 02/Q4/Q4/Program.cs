﻿//Q4
using System;

class Product
{
    public string ProductName { get; set; }
    public double Price { get; set; }

    public Product(string productName, double price)
    {
        ProductName = productName;
        Price = price;
    }
}

class Program
{
    static void Main(string[] args)
    {
        Product laptop = new Product("Laptop", 1899.99);
        Product IphonXR = new Product("IphonXR.", 799.99);

        Console.WriteLine("Product 1:");
        Console.WriteLine($"Name: {laptop.ProductName}, Price: {laptop.Price:N2} LKR");

        Console.WriteLine("\nProduct 2:");
        Console.WriteLine($"Name: {IphonXR.ProductName}, Price: {IphonXR.Price:N2} LKR");
    }
}