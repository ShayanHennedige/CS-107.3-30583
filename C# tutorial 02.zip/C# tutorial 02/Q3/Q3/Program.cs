﻿//Q3

using System;

class TemperatureTracker
{
    private double[] dailyTemperatures;

    public TemperatureTracker(int days)
    {
        dailyTemperatures = new double[days];
    }

    public void SetTemperature(int day, double temperature)
    {
        dailyTemperatures[day] = temperature;
    }

    public void DisplayWeeklyReport()
    {
        Console.WriteLine("Weekly Temperature Report:");
        for (int i = 0; i < dailyTemperatures.Length; i++)
        {
            Console.WriteLine($"Day {i + 1}: {dailyTemperatures[i]}°C");
        }
    }
}

class Program
{
    static void Main(string[] args)
    {
        TemperatureTracker tracker = new TemperatureTracker(7);

        tracker.SetTemperature(0, 25.5);
        tracker.SetTemperature(1, 24.8);
        tracker.SetTemperature(2, 26.3);
        tracker.SetTemperature(3, 23.9);
        tracker.SetTemperature(4, 27.6);
        tracker.SetTemperature(5, 25.5);
        tracker.SetTemperature(6, 26.8);

        tracker.DisplayWeeklyReport();
    }
}