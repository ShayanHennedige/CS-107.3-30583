﻿//Q1

using System;

class Book
{
    public string Title { get; set; }
    public string Author { get; set; }
}

class Program
{
    static void Main(string[] args)
    {
        
        Book myBook = new Book();

        
        myBook.Title = "The Beast Qest";
        myBook.Author = "Adam Blade";

        
        Console.WriteLine("Book Title: " + myBook.Title);
        Console.WriteLine("Book Author: " + myBook.Author);
    }
}