﻿
//Q1
using System;

class BankAccount
{
    public string AccountNumber { get; set; }
    public double Balance { get; private set; }

    public void Deposit(double amount)
    {
        if (amount <= 0)
        {
            Console.WriteLine("Invalid deposit amount.");
        }
        else
        {
            Balance += amount;
            Console.WriteLine($"Deposit of {amount} successful.");
        }
    }
}

class Program
{
    static void Main(string[] args)
    {
        BankAccount myAccount = new BankAccount();
        myAccount.AccountNumber = "006334534859";
        myAccount.Deposit(1500.0);
        Console.WriteLine($"Updated Balance: {myAccount.Balance}");
    }
}